<?php
/*
 * Plugin Name: Simple SMTP by Maileroo
 * Plugin URI: https://maileroo.com/
 * Description: Simplify WordPress email delivery with universal SMTP compatibility, including Maileroo, SendGrid, Mailgun, and more - all-in-one SMTP plugin for reliable, user-friendly email integration.
 * Version: 1.1.5.1
 * Text Domain: maileroo
 * Domain Path: /languages/
 * Author: Areeb
 * Author URI: https://areeb.com/
 * License: GPL v3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

define("SSBM_VERSION", "1.1.5.1");


function ssbm_menu() {

    add_menu_page(
        'Simple SMTP by Maileroo',
        'Simple SMTP',
        'manage_options',
        'simple-smtp-by-maileroo',
        'ssbm_page',
        plugins_url('/assets/icon.svg', __FILE__)
    );

}

add_action('admin_menu', 'ssbm_menu');

function ssbm_page() {
    include_once(plugin_dir_path(__FILE__) . 'components/home_page.php');
}

function ssbm_settings_init() {

    register_setting('ssbm_settings', 'ssbm_delivery_method', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => 'smtp',
    ]);

    register_setting('ssbm_settings', 'ssbm_api_sending_key', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => '',
    ]);

    register_setting('ssbm_settings', 'ssbm_smtp_host', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => 'smtp.maileroo.com',
    ]);

    register_setting('ssbm_settings', 'ssbm_smtp_port', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => '587',
    ]);

    register_setting('ssbm_settings', 'ssbm_authentication', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => 'on',
    ]);

    register_setting('ssbm_settings', 'ssbm_smtp_username', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => '',
    ]);

    register_setting('ssbm_settings', 'ssbm_smtp_password', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => '',
    ]);

    register_setting('ssbm_settings', 'ssbm_encryption', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => 'starttls',
    ]);

    register_setting('ssbm_settings', 'ssbm_from_email', [
        'sanitize_callback' => 'sanitize_email',
        'default' => '',
    ]);

    register_setting('ssbm_settings', 'ssbm_force_from', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => '',
    ]);

    register_setting('ssbm_settings', 'ssbm_from_name', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => '',
    ]);

}

add_action('admin_init', 'ssbm_settings_init');
add_action('wp_ajax_send_test_email', 'ssbm_send_test_email');

function ssbm_send_test_email() {

    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ssbm_nonce_test'])), 'ssbm_nonce_test')) {
        echo '<div class="error">'.__('Please reload the page and try again.', 'maileroo').'</div>';
        die();
    }

    $recipient_email = sanitize_email($_POST['recipient_email']);
    $subject = __('Test Email from Maileroo Plugin', 'maileroo');
    $message = __('This is a test email sent from the Maileroo Plugin.', 'maileroo');
    $headers = 'From: ' . get_option('ssbm_from_email') . "\r\n";

    add_action('wp_mail_failed', 'ssbm_capture_wp_mail_errors');

    $success = wp_mail($recipient_email, $subject, $message, $headers);

    remove_action('wp_mail_failed', 'ssbm_capture_wp_mail_errors');

    if ($success) {

        echo '<div class="updated">'.__('The test email has been sent successfully.', 'maileroo').'</div>';

    } else {

        $error_message = get_transient('ssbm_error_message');

        if (!empty($error_message)) {
            echo '<div class="error">'.__('Failed to send test email. Check your server settings and try again. Error: ', 'maileroo') . esc_html($error_message) . '</div>';
        } else {
            echo '<div class="error">'.__('Failed to send test email. Check your server settings and try again.', 'maileroo').'</div>';
        }

    }
    die();

}

function ssbm_capture_wp_mail_errors($wp_error) {

    $error_message = $wp_error->get_error_message();

    set_transient('ssbm_error_message', $error_message, 60);

}

function ssbm_enqueue_admin_styles($hook) {

    if ($hook != 'toplevel_page_simple-smtp-by-maileroo') {
        return;
    }

    wp_enqueue_style('ssbm_global_styles', plugins_url('/assets/global_styles.css', __FILE__), array(), SSBM_VERSION);
    wp_enqueue_style('ssbm_app_styles', plugin_dir_url(__FILE__) . 'assets/styles.css', array(), SSBM_VERSION);
    wp_enqueue_script('ssbm_scripts', plugin_dir_url(__FILE__) . 'assets/scripts.js', array(), SSBM_VERSION, true);

}

add_action('admin_enqueue_scripts', 'ssbm_enqueue_admin_styles');

if (get_option('ssbm_delivery_method', 'smtp') === 'smtp') {
    add_action('phpmailer_init', 'ssbm_custom_smtp_override');
} else {
    add_filter('pre_wp_mail', 'ssbm_custom_api_override', 10, 2);
}

add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), function($links) {
   $links[] = '<a href="'.admin_url('admin.php?page=simple-smtp-by-maileroo').'">'. __('Settings', 'maileroo'). '</a>';
   $links[] = '<a href="https://wordpress.org/support/plugin/simple-smtp-by-maileroo/reviews/#new-post" target="_blank">'. __('Rate it!', 'maileroo'). '</a>';
   return $links;
});

function ssbm_custom_api_override($null, $atts) {
    $message = $atts['message'];
    $to_array = array();

    $tos = (!is_array($atts['to'])) ? explode(',', $atts['to']) : $atts['to'];
    foreach ($tos as $to) {
        $to_array[] = array('address' => trim($to));
    }
    
    $subject = $atts['subject'];
    $attachments = $atts['attachments'];

    // If the plain text message is the same as the message without HTML tags, then convert the plain text message to HTML (looks good with line breaks)

    if ($message == strip_tags($message)) {
        $message = nl2br($message);
    }
    $payload = [
        'from' => array('display_name' => get_option('ssbm_from_name'), 'address' => get_option('ssbm_from_email')),
        'to' => $to_array,
        'subject' => $subject,
        'html' => $message,
    ];

    // Find any extra headers and add them to the payload

    if (!empty($atts['headers'])) {
        
        if (!is_array($atts['headers'])) {
            $headers = explode(PHP_EOL, $atts['headers']);
        } else {
            $headers = $atts['headers'];
        }
        
        $payload['headers'] = array();
        foreach ($headers as $header) {
            if (empty($header)) continue;
            if (preg_match('/^Reply-To: (.*)$/i', $header, $matches)) {
                $replyto = trim($matches[1]);
                if (is_email($replyto)) $payload['reply_to'] = array('address' => $replyto);
            } elseif (substr(strtolower($header), 0, 5) == 'from:') {
                $force = get_option('ssbm_force_from');
                if (empty($force)) {
                    $from = ssbm_parse_from_header($header);
                    $payload['from'] = $from[0];
                }
            } elseif (substr(strtolower($header), 0, 3) == 'cc:') {
                $payload['cc'] = ssbm_parse_from_header($header);

            } elseif (substr(strtolower($header), 0, 4) == 'bcc:') {
                $payload['bcc'] = ssbm_parse_from_header($header);

            } else {
                $header_pair = explode(':', $header);
                if ($header_pair[0] == 'Content-Type') continue;
                $payload['headers'][$header_pair[0]] = trim($header_pair[1]);
            }
        }
    }
    // Add attachments to the payload

    if (!empty($attachments)) {
        $payload['attachments'] = array();
        foreach ($attachments as $key => $attachment) {
            if ($attachment != '' && file_exists($attachment)) {
                $payload['attachments'][] = array(
                    'file_name' => basename($attachment),
                    'content_type' => mime_content_type($attachment),
                    'content' => base64_encode(file_get_contents($attachment)),
                    'inline' => false
                );
            }
        }
    }

    $api_url = 'https://smtp.maileroo.com/api/v2/emails';

    // If there's a registered filter for adding template data, then apply it

    $payload = apply_filters('ssbm_add_template_data', $payload, $atts);

    // If a template ID is set, then use the template sending endpoint

    if (!empty($payload['template_id'])) {
        $api_url .= '/template';
    }

    // add tags to the payload via the filter hook
    $payload = apply_filters('ssbm_add_tags_api_method', $payload);
    $payload_json = json_encode($payload, JSON_PRETTY_PRINT);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'X-API-Key: ' . get_option('ssbm_api_sending_key')]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload_json);
    $response = json_decode(curl_exec($ch), true);
    curl_close($ch);
    if ($response['success']) {

        return true;

    } else {

        do_action('wp_mail_failed', new WP_Error('email_failed', $response['message']));

        return false;

    }

}

function ssbm_custom_smtp_override($phpmailer) {

    $ssbm_smtp_host = get_option('ssbm_smtp_host', 'smtp.maileroo.com');
    $ssbm_smtp_port = get_option('ssbm_smtp_port', '587');
    $ssbm_authentication = get_option('ssbm_authentication', 'on');
    $ssbm_smtp_username = get_option('ssbm_smtp_username', '');
    $ssbm_smtp_password = get_option('ssbm_smtp_password', '');
    $ssbm_encryption = get_option('ssbm_encryption', 'starttls');
    
    $phpmailer->isSMTP();
    $phpmailer->Host = $ssbm_smtp_host;
    $phpmailer->Port = $ssbm_smtp_port;
    $phpmailer->SMTPAuth = $ssbm_authentication === 'on';
    $phpmailer->Username = $ssbm_smtp_username;
    $phpmailer->Password = $ssbm_smtp_password;
    $phpmailer->SMTPSecure = $ssbm_encryption;
    
    $force = get_option('ssbm_force_from');
    if (isset($force) && 'yes' == $force) {
        $phpmailer->From = get_option('ssbm_from_email', '');
    }
    if ($phpmailer->FromName == '') $phpmailer->FromName = get_option('ssbm_from_name', '');
    do_action('ssbm_add_custom_header', $phpmailer);
}

function ssbm_parse_from_header($header) {
    list( $type, $head_content ) = explode( ':', trim( $header ), 2 );
    $head_content = trim( $head_content );
    $head_array = explode(',', $head_content);
    $return = array();
    foreach ($head_array as $content) {
        $name = '';
        $email = '';
        $bracket_pos = strpos( $content, '<' );
        if ( false !== $bracket_pos ) {
            // Text before the bracketed email is the name.
            if ( $bracket_pos > 0 ) {
                $name = substr( $content, 0, $bracket_pos );
                $name = str_replace( '"', '', $name );
                $name = trim( $name );
            }
            $email = substr( $content, $bracket_pos + 1 );
            $email = str_replace( '>', '', $email );
            $email = trim( $email );
            // Avoid setting an empty $from_email.
        } elseif ( '' !== trim( $content ) ) {
            $email = trim( $content );
        }
        if ($name != '') {
            $return[] = array('address' => $email, 'display_name' => $name);
        } else {
            $return[] = array('address' => $email);
        }
    }
    return $return;
}

function ssbm_save_form() {
    do_action('ssbm_action_form');
}

add_action('admin_init', 'ssbm_save_form');

function ssbm_form_function_submit() {

    if (isset($_POST['submit']) && isset($_POST['ssbm_nonce'])) {

        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ssbm_nonce'])), 'ssbm_nonce')) {
            return;
        }
        setcookie('submit-result', 'success', time() + 1, '/');

    }

}

add_action('ssbm_action_form', 'ssbm_form_function_submit');