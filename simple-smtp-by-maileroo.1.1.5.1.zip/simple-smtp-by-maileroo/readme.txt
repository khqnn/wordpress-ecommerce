=== Simple SMTP by Maileroo ==

Contributors: areebmajeed, finalwebsites
Tags: smtp, mail, mailer, phpmailer, wp_mail
Requires at least: 4.6
Tested up to: 6.9
Stable tag: 1.1.5.1
License: GPL-3.0
License URI: https://www.gnu.org/licenses/gpl.html

Ensure seamless WordPress email delivery with our all-in-one SMTP plugin, compatible with Gmail, Outlook, Maileroo, SendGrid, Mailgun, and more!
   
== Description ==

Are you struggling with WordPress not sending emails correctly? Simple SMTP by <a href="https://maileroo.com">Maileroo</a> is here to solve that! This plugin is designed to ensure your WordPress emails are sent reliably and efficiently, using your preferred SMTP service.

We aim to simplify and secure email delivery, ensuring your messages consistently land in the inbox. Simple SMTP by Maileroo fixes your email reliability by helping you switch to a proper SMTP Relay such as Maileroo, MailGun, SendGrid, etc. Simple SMTP by Maileroo is free to use and has everything you need to send your emails via WordPress!

#### SMTP Explained

SMTP, or Simple Mail Transfer Protocol, is the industry standard for sending emails across the internet. It plays a critical role in the email delivery process, acting as the protocol that governs the transmission of emails from one server to another. Understanding SMTP is essential for anyone managing email communications, particularly in a WordPress environment. If you do not use a proper SMTP relay service, your emails might go to spam, compromising their effectiveness and reach.

#### HTTP API Integration

Now, with the latest update, Simple SMTP by Maileroo offers HTTP API integration with Maileroo. This feature allows you to send emails via the Maileroo API, without the need for SMTP credentials. This is a great option for users whose hosting providers block SMTP ports or for those who prefer to use the Maileroo API for email delivery.

#### SMTP Relay Providers

Here are some of the popular SMTP Relay providers, each offering unique features and benefits for different email delivery needs:

1. <a href="https://maileroo.com">Maileroo</a>
2. <a href="https://www.mailgun.com">Mailgun</a>
3. <a href="https://sendgrid.com">SendGrid</a>
4. <a href="https://aws.amazon.com/ses/">Amazon SES</a>
5. <a href="https://www.smtp.com">SMTP.com</a>
6. <a href="https://postmarkapp.com">Postmark</a>

== Installation ==

1. Install the Simple SMTP by Maileroo plugin either via the WordPress.org plugin repository or by uploading the files to your server.
2. Activate the plugin in your WordPress Admin Panel.
3. Navigate to the Settings page of the Simple SMTP plugin.
4. Fill in the SMTP settings for your service. If you don't have an SMTP provider, make sure to check out <a href="https://maileroo.com">Maileroo</a> for a free and reliable SMTP relay service.
5. Save changes and test your SMTP credentials.
6. Need more help? Let us know at our contact <a href="https://maileroo.com/contact">page</a>.

== Frequently Asked Questions ==

= Can Simple SMTP by Maileroo be used to send emails via Gmail, Outlook.com, Office 365, Yahoo, or other SMTP services? =

Absolutely! Simple SMTP by Maileroo is designed to be compatible with a wide range of email services including Maileroo, Gmail, Outlook.com, Office 365, Yahoo, and more.

= What should I do if I need support or encounter an issue? =

We're here to help! If you need any help with the plugin setup, just let us know!

Please visit <a href="https://maileroo.com/contact">our contact page</a> for more information.

= Are there plans to add new features to Simple SMTP by Maileroo? =

We're always open to suggestions! If there's a feature you'd like to see in Simple SMTP by Maileroo, please let us know. While we can't promise to implement every request, we seriously consider all feasible and sensible suggestions to enhance our plugin.


= Is it possible to add custom email headers (tags) to an email message? =

For the SMTP method of the plugin, you can easily add custom mail headers. In the example below, a tag header with the value of the "From Email" is added:
`
add_action('ssbm_add_custom_header', function($phpmailer) {
  $phpmailer->addCustomHeader('X-Tag-from', $phpmailer->From);
});
`
A similar filter hook is available for the Maileroo API method. The following example adds the same tag header to the email message.
`
add_filter('ssbm_add_tags_api_method', function($payload) {
  if (isset($payload['from']['address'])) {
    $payload['tags'] = array('from' => $payload['from']['address']);
  }
  return $payload;
});
`




== Screenshots ==

1. ![Desktop Screenshot](https://maileroo.com/media/plugins/simple-smtp-plugin-screenshot.png)

== Changelog ==

= v1.1.5.1

* Bug Fix: Fixed a problem with the API endpoint for templated emails.


= v1.1.5

* Improvement: I've added additional attachment validations to the Maileroo API mail function. This was necessary to prevent errors in certain situations.
* Other: I've added two useful links to the plugin on the plugin list page.

= v1.1.4

* Improvement: Cc, Bcc and From: headers are now also recognized when spelled in capital or lower case.

= v1.1.3.1 =

* Bug Fix: Fixed a problem with misspelled reply-to headers.

= v1.1.3

* Improvement: Support for "Cc:" and "Bcc:" headers was still missing when calling the Maileroo Email API v2. This is now possible for both types of headers.

= v1.1.2 =

* Bug Fix: Fixed a problem with an empty reply-to value from Elementor forms.

= v1.1.1 =

* Bug Fix: Fixed a problem with multiple email recipients.

= v1.1.0 =

* Improvement: Updated the API overide function to support the new Maileroo Email API v2. 
  UPDATE your custom filter hooks if you add tags to your emails (Check the FAQ for the updated example)
* Bug Fix: In this version the Reply-To header finally works, sorry for the additional updates yesterday.

= v1.0.10.1 =
= v1.0.10 =

* Bug Fix: Fixed Reply-to header for the API email mode.

= v1.0.9 =

* Improvement: It is now possible to add tags to an email message. See the FAQ section for the code examples.
* Improvement: The email "from:" header is no longer overwritten when it contains its own value.

= v1.0.8 =

* Bug Fix: Fixed the plugin header in order to support localization.

= v1.0.7 =

* Improvement: Prepared all code for localization.

= v1.0.6 =

* Bug Fix: In some situations the mail headers are not read correctly for the API version

= v1.0.5 =

* (Minor) Bug Fix

= v1.0.4 =

The following contributions were made by <a href="https://www.finalwebsites.com/">Olaf Lederer</a>.

* Improvement: Added the `ssbm_add_template_data` filter that allows third-party developers to use templates with the plugin.

= v1.0.3 =

The following contributions were made by <a href="https://www.finalwebsites.com/">Olaf Lederer</a>.

* Bug Fix: The plugin no longer loads the stylesheet unnecessarily.
* Improvement: The plugin will automatically add line-breaks and convert plaintext emails produced by WordPress.

= v1.0.2 =

* Bug fixes and improvements

= v1.0.1 =

* Added HTTP API integration with Maileroo

= v1.0.0 =

* Initial release