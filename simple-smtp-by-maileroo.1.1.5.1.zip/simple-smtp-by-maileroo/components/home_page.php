<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap maileroo--maileroo">

    <h1>
        <b>
            <?php esc_html_e( 'Simple SMTP by Maileroo', 'maileroo'); ?>
        </b>
    </h1>

    <form method="post" action="options.php">

        <?php
        settings_fields('ssbm_settings');
        do_settings_sections('ssbm-settings');
        ?>

        <table class="form-table">

            <?php
            wp_nonce_field('ssbm_settings', 'ssbm_nonce');
            ?>

            <tr>
                <th scope="row"><label for="ssbm_delivery_method"><?php esc_html_e( 'Method', 'maileroo'); ?></label></th>
                <td>
                    <fieldset>
                        <legend class="screen-reader-text"><span>ssbm_delivery_method</span></legend>
                        <label for="ssbm_delivery_method_smtp"><input type="radio" name="ssbm_delivery_method" id="ssbm_delivery_method_smtp" value="smtp" <?php checked('smtp', get_option('ssbm_delivery_method')) || checked('', get_option('ssbm_delivery_method')); ?> /> SMTP</label><br>
                        <label for="ssbm_delivery_method_mail"><input type="radio" name="ssbm_delivery_method" id="ssbm_delivery_method_mail" value="api" <?php checked('api', get_option('ssbm_delivery_method')); ?> /> Maileroo API</label><br>
                    </fieldset>
                </td>
            </tr>

            <tr>
                <td colspan="3">
                    <hr>
                </td>
            </tr>

            <tbody id="api-config-section" style="display: none;">

            <tr>
                <th scope="row"><label for="ssbm_api_sending_key"><?php esc_html_e( 'Sending Key', 'maileroo'); ?></label></th>
                <td><input type="text" name="ssbm_api_sending_key" id="ssbm_api_sending_key" value="<?php echo esc_attr(get_option('ssbm_api_sending_key', '')); ?>" class="regular-text"/></td>
            </tr>

            <tr>
                <td colspan="2" style="padding: 0;">
                    <p>
                    <?php 
                     /* translators: %s - https://maileroo.com/help/how-do-i-obtain-an-api-key-for-maileroo/  */ 
                    printf(wp_kses_post( 'You can find your sending key in <b>Sending Keys</b> section of your domain in Maileroo. For more information, please follow <a href="%s" target="_blank">this link</a>', 'maileroo'), esc_url('https://maileroo.com/help/how-do-i-obtain-an-api-key-for-maileroo/')); 
                    ?>
                    </p>
                </td>
            </tr>

            </tbody>

            <tbody id="smtp-config-section" style="display: none;">

            <tr>
                <th scope="row"><label for="ssbm_smtp_host"><?php esc_html_e( 'SMTP Host', 'maileroo'); ?></label></th>
                <td><input type="text" name="ssbm_smtp_host" id="ssbm_smtp_host" value="<?php echo esc_attr(get_option('ssbm_smtp_host', 'smtp.maileroo.com')); ?>" class="regular-text"/></td>
            </tr>

            <tr>
                <th scope="row"><label for="ssbm_smtp_port"><?php esc_html_e( 'SMTP Port', 'maileroo'); ?></label></th>
                <td><input type="text" name="ssbm_smtp_port" id="ssbm_smtp_port" value="<?php echo esc_attr(get_option('ssbm_smtp_port', '587')); ?>" class="small-text"/></td>
            </tr>

            <tr>
                <th scope="row"><?php esc_html_e( 'Authentication', 'maileroo'); ?></th>
                <td>
                    <div class="maileroo--custom-switch" id="ssbm_authentication-switch">
                        <input type="checkbox" name="ssbm_authentication" id="ssbm_authentication_checkbox" <?php checked('on', get_option('ssbm_authentication')); ?> />
                        <label for="ssbm_authentication_checkbox"></label>
                    </div>
                </td>
            </tr>

            <tr class="auth-input">
                <th scope="row"><label for="ssbm_smtp_username"><?php esc_html_e( 'Username', 'maileroo'); ?></label></th>
                <td><input type="text" name="ssbm_smtp_username" id="ssbm_smtp_username" value="<?php echo esc_attr(get_option('ssbm_smtp_username')); ?>" class="regular-text" <?php echo (get_option('ssbm_authentication') == 'on') ? '' : 'disabled'; ?>/></td>
            </tr>

            <tr class="auth-input">
                <th scope="row"><label for="ssbm_smtp_password"><?php esc_html_e( 'Password', 'maileroo'); ?></label></th>
                <td><input type="password" name="ssbm_smtp_password" id="ssbm_smtp_password" value="<?php echo esc_attr(get_option('ssbm_smtp_password')); ?>" class="regular-text" <?php echo (get_option('ssbm_authentication') == 'on') ? '' : 'disabled'; ?>/></td>
            </tr>

            <tr>
                <th scope="row">Encryption</th>
                <td>
                    <fieldset>
                        <legend class="screen-reader-text"><span>ssbm_encryption</span></legend>
                        <label for="ssbm_encryption_plaintext"><input type="radio" name="ssbm_encryption" id="ssbm_encryption_plaintext" value="plaintext" <?php checked('plaintext', get_option('ssbm_encryption')); ?> /> Plaintext</label><br>
                        <label for="ssbm_encryption_starttls"><input type="radio" name="ssbm_encryption" id="ssbm_encryption_starttls" value="starttls" <?php checked('starttls', get_option('ssbm_encryption')); ?> /> STARTTLS</label><br>
                        <label for="ssbm_encryption_ssl_tls"><input type="radio" name="ssbm_encryption" id="ssbm_encryption_ssl_tls" value="ssl_tls" <?php checked('ssl_tls', get_option('ssbm_encryption')); ?> /> SSL/TLS</label><br>
                    </fieldset>
                </td>
            </tr>

            </tbody>

            <tr>
                <td colspan="3">
                    <hr>
                </td>
            </tr>

            <tr>
                <th scope="row"><label for="ssbm_from_email"><?php esc_html_e( 'From Email', 'maileroo'); ?></label></th>
                <td><input type="text" name="ssbm_from_email" id="ssbm_from_email" value="<?php echo esc_attr(get_option('ssbm_from_email')); ?>" class="regular-text" required/></td>
            </tr>

            <tr>
                <th scope="row"><label for="ssbm_from_email"><?php esc_html_e('Force From Email', 'maileroo'); ?></label></th>
                <td>
                    <label for="ssbm_force_from">
                        <input type="checkbox" name="ssbm_force_from" id="ssbm_force_from" value="yes" <?php checked('yes', get_option('ssbm_force_from')); ?> /> 
                        <?php esc_html_e('If checked, the "From Email" Address will be used for all outgoing emails.', 'maileroo'); ?>
                    </label>
                </td>
            </tr>

            <tr>
                <th scope="row"><label for="ssbm_from_name"><?php esc_html_e( 'From Name', 'maileroo'); ?></label></th>
                <td><input type="text" name="ssbm_from_name" id="ssbm_from_name" value="<?php echo esc_attr(get_option('ssbm_from_name')); ?>" class="regular-text" required/></td>
            </tr>

        </table>

        <p class="submit">
            <?php submit_button(__( 'Save Changes', 'maileroo' ), 'maileroo--button maileroo--button-primary', 'submit', false); ?>

            <?php if (get_option('ssbm_from_email') && get_option('ssbm_from_name')) : ?>
                <button type="button" id="test-button" class="maileroo--button maileroo--button-outline"><?php esc_html_e( 'Test Connection', 'maileroo'); ?></button>
            <?php endif; ?>

        </p>

    </form>

    <div class="maileroo--maileroo-modal">
        <div id="test-modal" class="maileroo--modal">
            <div class="maileroo--modal-content">
                <div>
                    <span class="maileroo--close">&times;</span>
                    <h2><?php esc_html_e( 'Test Email Connection', 'maileroo'); ?></h2>
                </div>
                <div>
                    <div class="maileroo--modal-body">
                        <p><?php esc_html_e( 'Please enter the recipient email address:', 'maileroo'); ?></p>
                        <input type="hidden" id="ssbm_nonce_test" value="<?php echo esc_attr(wp_create_nonce('ssbm_nonce_test')); ?>">
                        <input type="email" id="recipient_email" name="recipient_email" class="regular-text" required/>
                        <button id="send-test-email" class="button"><?php esc_html_e( 'Send Email', 'maileroo'); ?></button>
                    </div>
                    <div class="maileroo--loading-container maileroo--display-none">
                        <div class="maileroo--loading"></div>
                    </div>
                    <div id="test-result"></div>
                </div>
            </div>
        </div>

    </div>

    <h4>
        <?php esc_html_e( 'Experience the pinnacle of email delivery with Maileroo! Our platform offers blazing-fast transactional email delivery, advanced tracking of delivery rates, opens, clicks, and bounces, and a straightforward setup process. Whether you prefer traditional SMTP or our efficient HTTP Email API, Maileroo is designed to ensure your emails always reach the inbox. Trusted by thousands worldwide for its scalability and reliability, Maileroo is your go-to solution for transactional email needs.', 'maileroo'); ?>
        <br/>
        <br/>
        
        <?php 
        /* translators: %s - https://maileroo.com/  */ 
        printf( wp_kses_post('Don\'t wait - Click <a href="%s" target="_blank">here</a> to sign up at Maileroo and transform your email delivery today.', 'maileroo'), esc_url('https://maileroo.com/')); 
        ?>
    </h4>

    <div class="maileroo--promo-message">
        <p class="maileroo--promo-p"><span>Made with ❤️ by </span><a href="https://maileroo.com" target="_blank"><img class="maileroo--maileroo-logo" src="<?php echo esc_html(plugin_dir_url(__FILE__)) . '../assets/logo.svg'; ?>" alt="Maileroo"></a></p>
    </div>

    <div id="maileroo--toast-container">
        <div id="toast" class="maileroo--success" style="display: none;">
        </div>
    </div>

</div>

<script>

    document.addEventListener('DOMContentLoaded', function () {

        initializeState();
        stateChanges();

    });

    const initializeState = () => {

        const deliveryMethodRadios = document.querySelectorAll('input[name="ssbm_delivery_method"]');

        const smtpConfigSection = document.getElementById('smtp-config-section');
        const apiConfigSection = document.getElementById('api-config-section');

        deliveryMethodRadios.forEach(radio => {

            if (radio.checked) {

                if (radio.value === 'smtp' || radio.value === '') {
                    smtpConfigSection.style.display = 'table-row-group';
                    apiConfigSection.style.display = 'none';
                } else {
                    smtpConfigSection.style.display = 'none';
                    apiConfigSection.style.display = 'table-row-group';
                }

            }

        });

    };

    const stateChanges = () => {

        const smtpConfigSection = document.getElementById('smtp-config-section');
        const apiConfigSection = document.getElementById('api-config-section');

        const deliveryMethodRadios = document.querySelectorAll('input[name="ssbm_delivery_method"]');

        deliveryMethodRadios.forEach(radio => {

            radio.addEventListener('change', function () {

                if (this.value === 'smtp' || this.value === '') {
                    smtpConfigSection.style.display = 'table-row-group';
                    apiConfigSection.style.display = 'none';
                } else {
                    smtpConfigSection.style.display = 'none';
                    apiConfigSection.style.display = 'table-row-group';
                }

            });

        });

    };

</script>